import { 
  Connection, 
  Keypair, 
  PublicKey, 
  Transaction, 
  sendAndConfirmTransaction,
  SystemProgram,
  LAMPORTS_PER_SOL
} from '@solana/web3.js';
import {
  createInitializeMintInstruction,
  getMinimumBalanceForRentExemptMint,
  MINT_SIZE,
  TOKEN_PROGRAM_ID,
  getAssociatedTokenAddress,
  createAssociatedTokenAccountInstruction,
  createMintToInstruction,
  createSetAuthorityInstruction,
  AuthorityType,
  getMint
} from '@solana/spl-token';
import { 
  DataV2, 
  createCreateMetadataAccountV3Instruction 
} from '@metaplex-foundation/mpl-token-metadata';

// Network configuration
export type NetworkType = 'mainnet' | 'devnet' | 'custom';

export interface NetworkConfig {
  type: NetworkType;
  customRpcUrl?: string;
}

// Token creation parameters
export interface TokenCreationParams {
  // Basic info
  tokenName: string;
  tokenSymbol: string;
  decimals: number;
  supply: number;
  description: string;
  
  // Image & Social
  imageUrl?: string;
  website?: string;
  twitter?: string;
  telegram?: string;
  discord?: string;
  
  // Extensions
  nonTransferable?: boolean;
  permanentDelegate?: boolean;
  permanentDelegateAddress?: string;
  confidentialTransfer?: boolean;
  confidentialTransferPolicy?: 'auto' | 'manual';
  transferFee?: boolean;
  transferFeePercentage?: number;
  transferFeeMaxAmount?: number;
  transferHook?: boolean;
  transferHookProgramId?: string;
  interestBearing?: boolean;
  interestRate?: number;
  defaultAccountState?: boolean;
  defaultAccountStateValue?: 'initialized' | 'frozen';
  
  // Advanced options
  network: NetworkConfig;
  recipientWallet?: string;
  mintAuthority?: string;
  freezeAuthority?: string;
}

// Token creation result
export interface TokenCreationResult {
  success: boolean;
  tokenMintAddress?: string;
  tokenAccountAddress?: string;
  transactionSignature?: string;
  error?: string;
}

// Get connection based on network configuration
export const getConnection = (networkConfig: NetworkConfig): Connection => {
  let endpoint: string;
  
  switch (networkConfig.type) {
    case 'mainnet':
      endpoint = 'https://api.mainnet-beta.solana.com';
      break;
    case 'devnet':
      endpoint = 'https://api.devnet.solana.com';
      break;
    case 'custom':
      if (!networkConfig.customRpcUrl) {
        throw new Error('Custom RPC URL is required for custom network type');
      }
      endpoint = networkConfig.customRpcUrl;
      break;
    default:
      endpoint = 'https://api.devnet.solana.com';
  }
  
  return new Connection(endpoint, 'confirmed');
};

// Create token metadata
const createTokenMetadata = (params: TokenCreationParams): DataV2 => {
  // Prepare social links for URI JSON
  const socialLinks: Record<string, string> = {};
  if (params.website) socialLinks.website = params.website;
  if (params.twitter) socialLinks.twitter = params.twitter;
  if (params.telegram) socialLinks.telegram = params.telegram;
  if (params.discord) socialLinks.discord = params.discord;
  
  // Create URI JSON
  const uriData = {
    name: params.tokenName,
    symbol: params.tokenSymbol,
    description: params.description,
    image: params.imageUrl || '',
    external_url: params.website || '',
    links: socialLinks
  };
  
  // For a real implementation, this URI should be uploaded to Arweave or IPFS
  // For now, we'll use a data URI
  const uri = `data:application/json,${encodeURIComponent(JSON.stringify(uriData))}`;
  
  return {
    name: params.tokenName,
    symbol: params.tokenSymbol,
    uri,
    sellerFeeBasisPoints: 0,
    creators: null,
    collection: null,
    uses: null
  };
};

// Create a new token
export const createToken = async (
  wallet: any, // This will be the connected wallet (Phantom or Solflare)
  params: TokenCreationParams
): Promise<TokenCreationResult> => {
  try {
    // Get connection based on network configuration
    const connection = getConnection(params.network);
    
    // Get wallet public key
    const walletPublicKey = new PublicKey(wallet.publicKey.toString());
    
    // Create mint account
    const mintKeypair = Keypair.generate();
    const mintAddress = mintKeypair.publicKey;
    
    // Calculate rent for mint
    const lamports = await getMinimumBalanceForRentExemptMint(connection);
    
    // Create token metadata
    const tokenMetadata = createTokenMetadata(params);
    
    // Get token metadata program ID
    const TOKEN_METADATA_PROGRAM_ID = new PublicKey('metaqbxxUerdq28cj1RbAWkYQm3ybzjb6a8bt518x1s');
    
    // Get metadata account address
    const [metadataAddress] = PublicKey.findProgramAddressSync(
      [
        Buffer.from('metadata'),
        TOKEN_METADATA_PROGRAM_ID.toBuffer(),
        mintAddress.toBuffer(),
      ],
      TOKEN_METADATA_PROGRAM_ID
    );
    
    // Create recipient wallet public key
    let recipientPublicKey = walletPublicKey;
    if (params.recipientWallet) {
      recipientPublicKey = new PublicKey(params.recipientWallet);
    }
    
    // Get associated token account address
    const associatedTokenAddress = await getAssociatedTokenAddress(
      mintAddress,
      recipientPublicKey
    );
    
    // Create transaction
    const transaction = new Transaction();
    
    // Add instruction to create mint account
    transaction.add(
      SystemProgram.createAccount({
        fromPubkey: walletPublicKey,
        newAccountPubkey: mintAddress,
        space: MINT_SIZE,
        lamports,
        programId: TOKEN_PROGRAM_ID,
      })
    );
    
    // Add instruction to initialize mint
    transaction.add(
      createInitializeMintInstruction(
        mintAddress,
        params.decimals,
        walletPublicKey,
        walletPublicKey,
        TOKEN_PROGRAM_ID
      )
    );
    
    // Add instruction to create metadata account
    transaction.add(
      createCreateMetadataAccountV3Instruction(
        {
          metadata: metadataAddress,
          mint: mintAddress,
          mintAuthority: walletPublicKey,
          payer: walletPublicKey,
          updateAuthority: walletPublicKey,
        },
        {
          createMetadataAccountArgsV3: {
            data: tokenMetadata,
            isMutable: true,
            collectionDetails: null,
          },
        },
        TOKEN_METADATA_PROGRAM_ID
      )
    );
    
    // Add instruction to create associated token account
    transaction.add(
      createAssociatedTokenAccountInstruction(
        walletPublicKey,
        associatedTokenAddress,
        recipientPublicKey,
        mintAddress
      )
    );
    
    // Add instruction to mint tokens
    const mintAmount = params.supply * Math.pow(10, params.decimals);
    transaction.add(
      createMintToInstruction(
        mintAddress,
        associatedTokenAddress,
        walletPublicKey,
        BigInt(mintAmount)
      )
    );
    
    // If mint authority should be disabled
    if (!params.mintAuthority) {
      transaction.add(
        createSetAuthorityInstruction(
          mintAddress,
          walletPublicKey,
          AuthorityType.MintTokens,
          null
        )
      );
    }
    
    // If freeze authority should be disabled
    if (!params.freezeAuthority) {
      transaction.add(
        createSetAuthorityInstruction(
          mintAddress,
          walletPublicKey,
          AuthorityType.FreezeAccount,
          null
        )
      );
    }
    
    // Sign and send transaction
    const signature = await wallet.sendTransaction(transaction, connection, {
      signers: [mintKeypair],
    });
    
    // Confirm transaction
    await connection.confirmTransaction(signature, 'confirmed');
    
    // Return result
    return {
      success: true,
      tokenMintAddress: mintAddress.toString(),
      tokenAccountAddress: associatedTokenAddress.toString(),
      transactionSignature: signature,
    };
  } catch (error) {
    console.error('Error creating token:', error);
    return {
      success: false,
      error: error instanceof Error ? error.message : 'Unknown error',
    };
  }
};

// Get token info
export const getTokenInfo = async (
  connection: Connection,
  mintAddress: string
): Promise<any> => {
  try {
    const mintPublicKey = new PublicKey(mintAddress);
    const mintInfo = await getMint(connection, mintPublicKey);
    
    return {
      address: mintAddress,
      supply: Number(mintInfo.supply) / Math.pow(10, mintInfo.decimals),
      decimals: mintInfo.decimals,
      mintAuthority: mintInfo.mintAuthority?.toString() || null,
      freezeAuthority: mintInfo.freezeAuthority?.toString() || null,
    };
  } catch (error) {
    console.error('Error getting token info:', error);
    throw error;
  }
};
