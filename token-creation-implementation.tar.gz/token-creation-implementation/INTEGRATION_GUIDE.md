# Solana Token Creation Implementation Guide

This guide provides instructions for integrating the token creation functionality into your existing Next.js application.

## Overview

The implementation includes:

1. Token creation service with Solana Web3.js and SPL Token integration
2. Wallet integration with support for Solflare and Phantom wallets
3. Liquidity pool creation functionality
4. Complete workflow UI for token creation and liquidity pool setup

## Installation Instructions

### 1. Install Required Dependencies

Add the following dependencies to your project:

```bash
npm install @solana/web3.js @solana/spl-token @solana/wallet-adapter-react @solana/wallet-adapter-react-ui @solana/wallet-adapter-base @solana/wallet-adapter-wallets @metaplex-foundation/mpl-token-metadata
```

### 2. Copy Implementation Files

Copy the following files from the `token-creation-implementation` directory to your project:

- `tokenCreationService.ts` → `src/token-creation/tokenCreationService.ts`
- `WalletIntegration.tsx` → `src/token-creation/WalletIntegration.tsx`
- `WalletContextProvider.tsx` → `src/token-creation/WalletContextProvider.tsx`
- `LiquidityPoolCreator.tsx` → `src/token-creation/LiquidityPoolCreator.tsx`
- `TokenCreationWorkflow.tsx` → `src/token-creation/TokenCreationWorkflow.tsx`

### 3. Update Your Create Token Page

Replace the content of `src/app/create-token/page.tsx` with:

```tsx
import React from 'react';
import Layout from '@/components/layout/Layout';
import dynamic from 'next/dynamic';

// Import the token creation form with SSR disabled to prevent hydration errors
const TokenCreationFormUpdated = dynamic(
  () => import('@/token-creation/TokenCreationFormUpdated'),
  { ssr: false }
);

export default function CreateTokenPage() {
  return (
    <Layout>
      <div className="py-8">
        <h1 className="text-3xl font-bold text-center mb-8">Create Your Solana Token</h1>
        <div className="max-w-4xl mx-auto">
          <div className="bg-gradient-to-r from-purple-100 to-blue-100 p-6 rounded-lg mb-8">
            <h2 className="text-xl font-semibold mb-3">How to Create a Solana Token</h2>
            <p className="mb-4">
              Creating your own Solana token is simple with our easy-to-use interface. Follow these steps:
            </p>
            <ol className="list-decimal list-inside space-y-2 ml-4">
              <li>Connect your Solana wallet (Solflare or Phantom)</li>
              <li>Fill in the basic information for your token</li>
              <li>Upload an image and add social links (optional)</li>
              <li>Configure any token extensions you need</li>
              <li>Review and submit</li>
            </ol>
            <p className="mt-4 text-sm">
              Note: Token creation on mainnet requires SOL to pay for transaction fees.
            </p>
          </div>
          
          <TokenCreationFormUpdated />
        </div>
      </div>
    </Layout>
  );
}
```

### 4. Create the TokenCreationFormUpdated Component

Create a new file at `src/token-creation/TokenCreationFormUpdated.tsx` with the content from the provided implementation.

### 5. Update Your Layout Component

Update your layout component to use the dynamic wallet provider. In `src/components/layout/Layout.tsx`:

```tsx
'use client';

import React from 'react';
import Header from './Header';
import Footer from './Footer';
import dynamic from 'next/dynamic';

// Import wallet adapter CSS
import '@solana/wallet-adapter-react-ui/styles.css';

// Import wallet provider with SSR disabled
const WalletContextProvider = dynamic(
  () => import('@/token-creation/WalletContextProvider'),
  { ssr: false }
);

interface LayoutProps {
  children: React.ReactNode;
}

const Layout: React.FC<LayoutProps> = ({ children }) => {
  return (
    <WalletContextProvider>
      <div className="flex flex-col min-h-screen">
        <Header />
        <main className="flex-grow container mx-auto px-4 py-8">
          {children}
        </main>
        <Footer />
      </div>
    </WalletContextProvider>
  );
};

export default Layout;
```

## Usage Instructions

### Creating a Token

1. Navigate to the Create Token page
2. Connect your Solflare or Phantom wallet using the "Connect Wallet" button
3. Fill in the token details:
   - Name
   - Symbol
   - Decimals (default: 9)
   - Supply
   - Description
4. Add optional image and social links
5. Configure any token extensions if needed
6. Click "Create Token" to mint your token
7. After successful creation, you'll see the token details and can proceed to create a liquidity pool

### Creating a Liquidity Pool

1. After creating your token, you'll be automatically directed to the liquidity pool creation step
2. Enter the amount of SOL and tokens you want to add to the pool
3. Set your slippage tolerance
4. Click "Create Liquidity Pool" to create the pool
5. After successful creation, you'll see the pool details

## Customization Options

### Network Configuration

By default, the implementation is set to use the Solana mainnet. You can change this by modifying the `network` parameter in the `WalletContextProvider` component:

```tsx
<WalletContextProvider network="devnet">
  {/* Your components */}
</WalletContextProvider>
```

Options include:
- `mainnet` - Solana mainnet
- `devnet` - Solana devnet (for testing)
- `testnet` - Solana testnet

### Wallet Adapters

The implementation includes support for multiple wallets, with Solflare prioritized as requested. You can modify the list of supported wallets in the `WalletContextProvider.tsx` file.

## Troubleshooting

### Wallet Connection Issues

If you experience issues connecting your wallet:

1. Make sure you have the wallet extension installed in your browser
2. Check that you're on the correct network in your wallet (mainnet/devnet)
3. Try refreshing the page and reconnecting

### Token Creation Failures

If token creation fails:

1. Ensure you have enough SOL in your wallet to cover transaction fees
2. Check the browser console for detailed error messages
3. Verify that all required fields are filled correctly

## Additional Resources

- [Solana Web3.js Documentation](https://solana-labs.github.io/solana-web3.js/)
- [SPL Token Documentation](https://spl.solana.com/token)
- [Solana Wallet Adapter Documentation](https://github.com/solana-labs/wallet-adapter)
