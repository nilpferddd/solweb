'use client';

import React, { useEffect, useState } from 'react';
import { useWallet } from '@solana/wallet-adapter-react';
import { WalletMultiButton } from '@solana/wallet-adapter-react-ui';
import { createToken, TokenCreationParams, TokenCreationResult } from '../../token-creation-implementation/tokenCreationService';

interface WalletProviderProps {
  children: React.ReactNode;
}

export const WalletConnectionProvider: React.FC<WalletProviderProps> = ({ children }) => {
  const { wallet, publicKey, connected } = useWallet();
  const [isConnecting, setIsConnecting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (connected) {
      setIsConnecting(false);
      setError(null);
    }
  }, [connected]);

  const handleConnect = async () => {
    setIsConnecting(true);
    setError(null);
    
    try {
      if (wallet && !connected) {
        await wallet.adapter.connect();
      }
    } catch (err) {
      console.error('Failed to connect wallet:', err);
      setError(err instanceof Error ? err.message : 'Failed to connect wallet');
    } finally {
      setIsConnecting(false);
    }
  };

  return (
    <div className="wallet-connection-provider">
      <div className="flex justify-end mb-4">
        <WalletMultiButton className="wallet-adapter-button" />
      </div>
      
      {error && (
        <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">
          <p>{error}</p>
        </div>
      )}
      
      {children}
    </div>
  );
};

interface TokenCreatorProps {
  onTokenCreated?: (result: TokenCreationResult) => void;
  formData: TokenCreationParams;
}

export const TokenCreator: React.FC<TokenCreatorProps> = ({ onTokenCreated, formData }) => {
  const { publicKey, connected, wallet } = useWallet();
  const [isCreating, setIsCreating] = useState(false);
  const [result, setResult] = useState<TokenCreationResult | null>(null);
  const [error, setError] = useState<string | null>(null);

  const handleCreateToken = async () => {
    if (!connected || !wallet) {
      setError('Please connect your wallet first');
      return;
    }

    setIsCreating(true);
    setError(null);
    
    try {
      // Create token
      const creationResult = await createToken(wallet, formData);
      
      setResult(creationResult);
      
      if (onTokenCreated) {
        onTokenCreated(creationResult);
      }
      
      if (!creationResult.success) {
        setError(creationResult.error || 'Failed to create token');
      }
    } catch (err) {
      console.error('Error creating token:', err);
      setError(err instanceof Error ? err.message : 'An error occurred while creating the token');
    } finally {
      setIsCreating(false);
    }
  };

  return (
    <div className="token-creator">
      {!connected ? (
        <div className="text-center p-6 bg-gray-100 rounded-lg">
          <p className="mb-4">Connect your wallet to create a token</p>
          <WalletMultiButton className="wallet-adapter-button" />
        </div>
      ) : (
        <div>
          {result && result.success ? (
            <div className="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-4">
              <h3 className="font-bold mb-2">Token Created Successfully!</h3>
              <p className="mb-1"><strong>Token Mint Address:</strong> {result.tokenMintAddress}</p>
              <p className="mb-1"><strong>Token Account:</strong> {result.tokenAccountAddress}</p>
              <p><strong>Transaction:</strong> {result.transactionSignature}</p>
            </div>
          ) : (
            <button
              onClick={handleCreateToken}
              disabled={isCreating}
              className={`w-full py-3 px-4 rounded-lg font-semibold text-white ${
                isCreating ? 'bg-purple-400' : 'bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700'
              }`}
            >
              {isCreating ? 'Creating Token...' : 'Create Token'}
            </button>
          )}
          
          {error && (
            <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mt-4">
              <p>{error}</p>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
