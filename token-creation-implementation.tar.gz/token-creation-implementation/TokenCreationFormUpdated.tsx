'use client';

import React, { useState } from 'react';
import { WalletContextProvider } from '@/token-creation/WalletContextProvider';
import { TokenCreationWorkflow } from '@/token-creation/TokenCreationWorkflow';
import { TokenCreationParams } from '@/token-creation/tokenCreationService';

export default function TokenCreationFormUpdated() {
  // Basic Info Form State
  const [basicInfoData, setBasicInfoData] = useState({
    tokenName: '',
    tokenSymbol: '',
    decimals: 9,
    supply: 1000000,
    description: '',
  });
  
  // Image & Social Form State
  const [imageSocialData, setImageSocialData] = useState({
    imageUrl: '',
    website: '',
    twitter: '',
    telegram: '',
    discord: '',
  });
  
  // Extensions Form State
  const [extensionsData, setExtensionsData] = useState({
    nonTransferable: false,
    permanentDelegate: false,
    permanentDelegateAddress: '',
    confidentialTransfer: false,
    confidentialTransferPolicy: 'auto' as 'auto' | 'manual',
    transferFee: false,
    transferFeePercentage: 0,
    transferFeeMaxAmount: 0,
    transferHook: false,
    transferHookProgramId: '',
    interestBearing: false,
    interestRate: 0,
    defaultAccountState: false,
    defaultAccountStateValue: 'initialized' as 'initialized' | 'frozen',
  });
  
  // Advanced Options Form State
  const [advancedOptionsData, setAdvancedOptionsData] = useState({
    network: {
      type: 'mainnet' as 'mainnet' | 'devnet' | 'custom',
      customRpcUrl: '',
    },
    recipientWallet: '',
    mintAuthority: '',
    freezeAuthority: '',
  });
  
  // Combine all form data into token creation params
  const formData: TokenCreationParams = {
    ...basicInfoData,
    ...imageSocialData,
    ...extensionsData,
    network: advancedOptionsData.network,
    recipientWallet: advancedOptionsData.recipientWallet,
    mintAuthority: advancedOptionsData.mintAuthority,
    freezeAuthority: advancedOptionsData.freezeAuthority,
  };
  
  return (
    <div className="max-w-3xl mx-auto bg-white rounded-lg shadow-md p-6">
      <h1 className="text-2xl font-bold text-center mb-6">Create Solana Token</h1>
      
      <WalletContextProvider network="mainnet">
        <TokenCreationWorkflow initialFormData={formData} />
      </WalletContextProvider>
    </div>
  );
}
