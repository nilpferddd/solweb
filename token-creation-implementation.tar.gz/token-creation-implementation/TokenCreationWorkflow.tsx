'use client';

import React, { useState, useEffect } from 'react';
import { useWallet } from '@solana/wallet-adapter-react';
import { TokenCreationParams, TokenCreationResult } from './tokenCreationService';
import { TokenCreator } from './WalletIntegration';
import { LiquidityPoolCreator } from './LiquidityPoolCreator';

interface TokenCreationWorkflowProps {
  initialFormData: TokenCreationParams;
}

export const TokenCreationWorkflow: React.FC<TokenCreationWorkflowProps> = ({ initialFormData }) => {
  const { connected } = useWallet();
  const [formData, setFormData] = useState<TokenCreationParams>(initialFormData);
  const [tokenCreationResult, setTokenCreationResult] = useState<TokenCreationResult | null>(null);
  const [currentStep, setCurrentStep] = useState<'token-creation' | 'liquidity-pool'>('token-creation');
  
  const handleTokenCreated = (result: TokenCreationResult) => {
    setTokenCreationResult(result);
    if (result.success) {
      setCurrentStep('liquidity-pool');
    }
  };
  
  const handleLiquidityPoolCreated = (result: any) => {
    // Handle liquidity pool creation result
    console.log('Liquidity pool created:', result);
  };
  
  return (
    <div className="token-creation-workflow">
      {currentStep === 'token-creation' ? (
        <div className="token-creation-step">
          <TokenCreator 
            formData={formData} 
            onTokenCreated={handleTokenCreated} 
          />
        </div>
      ) : (
        <div className="liquidity-pool-step">
          <div className="mb-6">
            <h2 className="text-2xl font-bold mb-2">Token Created Successfully!</h2>
            <p className="text-green-600 mb-4">Your token has been created. You can now create a liquidity pool for it.</p>
            
            <div className="bg-gray-100 p-4 rounded-lg mb-4">
              <p className="mb-1"><strong>Token Mint Address:</strong> {tokenCreationResult?.tokenMintAddress}</p>
              <p className="mb-1"><strong>Token Account:</strong> {tokenCreationResult?.tokenAccountAddress}</p>
              <p><strong>Transaction:</strong> {tokenCreationResult?.transactionSignature}</p>
            </div>
          </div>
          
          {tokenCreationResult?.tokenMintAddress && (
            <LiquidityPoolCreator 
              tokenMintAddress={tokenCreationResult.tokenMintAddress}
              onLiquidityPoolCreated={handleLiquidityPoolCreated}
            />
          )}
          
          <button
            onClick={() => setCurrentStep('token-creation')}
            className="mt-4 py-2 px-4 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-100"
          >
            Back to Token Creation
          </button>
        </div>
      )}
    </div>
  );
};

export default TokenCreationWorkflow;
